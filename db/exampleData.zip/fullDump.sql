-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Wersja serwera:               10.7.1-MariaDB-1:10.7.1+maria~focal - mariadb.org binary distribution
-- Serwer OS:                    debian-linux-gnu
-- HeidiSQL Wersja:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Zrzut struktury bazy danych thesis
DROP DATABASE IF EXISTS `thesis`;
CREATE DATABASE IF NOT EXISTS `thesis` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `thesis`;

-- Zrzut struktury tabela thesis.failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.failed_jobs: ~0 rows (około)
DELETE FROM `failed_jobs`;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.files
DROP TABLE IF EXISTS `files`;
CREATE TABLE IF NOT EXISTS `files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.files: ~8 rows (około)
DELETE FROM `files`;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` (`id`, `filename`, `original_filename`, `created_at`, `updated_at`) VALUES
	(1, 'd27584ab4ecd191ac85819ea0244497d.pdf', 'Original Order.pdf', '2022-01-26 21:14:51', '2022-01-26 21:14:51'),
	(2, '5411a4187e3eb45a92289a183dfedc9f.jpg', 'Items.jpg', '2022-01-26 21:19:54', '2022-01-26 21:19:54'),
	(3, 'ff71372d153e50f36013168082e78b66.pdf', 'Measurments.pdf', '2022-01-26 21:20:44', '2022-01-26 21:20:44'),
	(4, 'f72d72e0433edd25a1b888128646ee23.pdf', 'Emails.pdf', '2022-01-26 21:23:03', '2022-01-26 21:23:03'),
	(5, '737aae5a8425056c03bbca72093bf2de.pdf', 'Invoice.pdf', '2022-01-26 21:25:26', '2022-01-26 21:25:26'),
	(6, 'd2e400077e7ff8f2935ebf09d5cc8f79.pdf', 'Waybill.pdf', '2022-01-26 21:27:38', '2022-01-26 21:27:38'),
	(7, 'a3a316de7ba32d0966ad390fb3841eb9.pdf', 'Certificate.pdf', '2022-01-26 21:29:55', '2022-01-26 21:29:55'),
	(8, '331e8397807e65be4f838ccd95787880.pdf', 'Stickers.pdf', '2022-01-26 21:36:01', '2022-01-26 21:36:01');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.file_order
DROP TABLE IF EXISTS `file_order`;
CREATE TABLE IF NOT EXISTS `file_order` (
  `order_id` bigint(20) unsigned NOT NULL,
  `file_id` bigint(20) unsigned NOT NULL,
  KEY `file_order_order_id_foreign` (`order_id`),
  KEY `file_order_file_id_foreign` (`file_id`),
  CONSTRAINT `file_order_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE,
  CONSTRAINT `file_order_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.file_order: ~9 rows (około)
DELETE FROM `file_order`;
/*!40000 ALTER TABLE `file_order` DISABLE KEYS */;
INSERT INTO `file_order` (`order_id`, `file_id`) VALUES
	(1, 1),
	(2, 4),
	(2, 1),
	(3, 6),
	(3, 1),
	(1, 7),
	(1, 4),
	(2, 7),
	(2, 6),
	(3, 7);
/*!40000 ALTER TABLE `file_order` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.file_task
DROP TABLE IF EXISTS `file_task`;
CREATE TABLE IF NOT EXISTS `file_task` (
  `task_id` bigint(20) unsigned NOT NULL,
  `file_id` bigint(20) unsigned NOT NULL,
  KEY `file_task_task_id_foreign` (`task_id`),
  KEY `file_task_file_id_foreign` (`file_id`),
  CONSTRAINT `file_task_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE,
  CONSTRAINT `file_task_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.file_task: ~29 rows (około)
DELETE FROM `file_task`;
/*!40000 ALTER TABLE `file_task` DISABLE KEYS */;
INSERT INTO `file_task` (`task_id`, `file_id`) VALUES
	(1, 2),
	(1, 3),
	(2, 4),
	(3, 4),
	(3, 5),
	(3, 2),
	(4, 6),
	(6, 2),
	(6, 6),
	(6, 7),
	(7, 5),
	(8, 2),
	(8, 6),
	(9, 2),
	(9, 3),
	(10, 7),
	(11, 4),
	(11, 5),
	(12, 2),
	(12, 8),
	(13, 6),
	(14, 3),
	(14, 2),
	(15, 5),
	(15, 4),
	(16, 2),
	(17, 7),
	(16, 8),
	(18, 6);
/*!40000 ALTER TABLE `file_task` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.jobs
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.jobs: ~0 rows (około)
DELETE FROM `jobs`;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.migrations: ~10 rows (około)
DELETE FROM `migrations`;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2021_12_03_112744_create_users_table', 1),
	(2, '2021_12_07_151421_create_orders_table', 1),
	(3, '2021_12_09_160135_create_tasks_table', 1),
	(4, '2021_12_11_170808_create_password_resets_table', 1),
	(5, '2021_12_25_113622_create_files_table', 1),
	(6, '2021_12_25_152837_create_file_order_table', 1),
	(7, '2021_12_26_201638_create_file_task_table', 1),
	(8, '2021_12_29_143021_create_notifications_table', 1),
	(9, '2021_12_30_122138_create_jobs_table', 1),
	(10, '2021_12_30_122251_create_failed_jobs_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.notifications
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_order_id_foreign` (`order_id`),
  KEY `notifications_user_id_foreign` (`user_id`),
  CONSTRAINT `notifications_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.notifications: ~51 rows (około)
DELETE FROM `notifications`;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` (`id`, `content`, `order_id`, `user_id`, `created_at`, `updated_at`) VALUES
	(1, 'User mbrzezinski@winsal.com was added', NULL, 2, '2021-12-31 18:06:02', '2021-12-31 18:06:02'),
	(2, 'User gziolkowska@winsal.com was added', NULL, 2, '2021-12-31 18:07:01', '2021-12-31 18:07:01'),
	(3, 'User gziolkowska@winsal.com was added', NULL, 3, '2021-12-31 18:07:01', '2021-12-31 18:07:01'),
	(4, 'User ejankowski@winsal.com was added', NULL, 2, '2021-12-31 18:08:01', '2021-12-31 18:08:01'),
	(5, 'User ejankowski@winsal.com was added', NULL, 3, '2021-12-31 18:08:01', '2021-12-31 18:08:01'),
	(6, 'User ejankowski@winsal.com was added', NULL, 4, '2021-12-31 18:08:01', '2021-12-31 18:08:01'),
	(7, 'A new order has been created. Walzwerk Winsal due on 2022-03-15', 1, 2, '2022-01-26 21:16:01', '2022-01-26 21:16:01'),
	(8, 'A new order has been created. Walzwerk Winsal due on 2022-03-15', 1, 3, '2022-01-26 21:16:01', '2022-01-26 21:16:01'),
	(9, 'A new order has been created. Walzwerk Winsal due on 2022-03-15', 1, 4, '2022-01-26 21:16:01', '2022-01-26 21:16:01'),
	(10, 'A new order has been created. Walzwerk Winsal due on 2022-03-15', 1, 5, '2022-01-26 21:16:01', '2022-01-26 21:16:01'),
	(11, 'User jrajca@winsal.com assigned you to Measure Items', 1, 2, '2022-01-26 21:19:01', '2022-01-26 21:19:01'),
	(12, 'User jrajca@winsal.com edited your task - Measure Items', 1, 2, '2022-01-26 21:21:02', '2022-01-26 21:21:02'),
	(13, 'User jrajca@winsal.com assigned you to Find a cutter and order a service', 1, 4, '2022-01-26 21:24:02', '2022-01-26 21:24:02'),
	(14, 'User jrajca@winsal.com assigned you to Prepare shippment for cutting', 1, 3, '2022-01-26 21:26:01', '2022-01-26 21:26:01'),
	(15, 'User jrajca@winsal.com edited your task - Prepare shippment for cutting', 1, 3, '2022-01-26 21:27:01', '2022-01-26 21:27:01'),
	(16, 'User jrajca@winsal.com assigned you to Ship Items For Cutting (28.01.2022)', 1, 2, '2022-01-26 21:28:01', '2022-01-26 21:28:01'),
	(17, 'User jrajca@winsal.com assigned you to Measure Items Again', 1, 2, '2022-01-26 21:29:02', '2022-01-26 21:29:02'),
	(18, 'User jrajca@winsal.com edited your task - Measure Items Again', 1, 2, '2022-01-26 21:29:02', '2022-01-26 21:29:02'),
	(19, 'User jrajca@winsal.com assigned you to Receive cutted items (~01.02.2022)', 1, 2, '2022-01-26 21:30:01', '2022-01-26 21:30:01'),
	(20, 'A new order has been created. Politechnika Czestochowska due on 2022-01-28', 2, 2, '2022-01-26 21:32:02', '2022-01-26 21:32:02'),
	(21, 'A new order has been created. Politechnika Czestochowska due on 2022-01-28', 2, 3, '2022-01-26 21:32:02', '2022-01-26 21:32:02'),
	(22, 'A new order has been created. Politechnika Czestochowska due on 2022-01-28', 2, 4, '2022-01-26 21:32:02', '2022-01-26 21:32:02'),
	(23, 'A new order has been created. Politechnika Czestochowska due on 2022-01-28', 2, 5, '2022-01-26 21:32:02', '2022-01-26 21:32:02'),
	(24, 'User jrajca@winsal.com assigned you to Order items', 2, 5, '2022-01-26 21:33:01', '2022-01-26 21:33:01'),
	(25, 'User jrajca@winsal.com assigned you to Receive the delivery (15.01.2022)', 2, 3, '2022-01-26 21:34:02', '2022-01-26 21:34:02'),
	(26, 'User jrajca@winsal.com assigned you to Measure Items', 2, 4, '2022-01-26 21:34:02', '2022-01-26 21:34:02'),
	(27, 'User jrajca@winsal.com assigned you to Generate a certifacte of security', 2, 5, '2022-01-26 21:35:01', '2022-01-26 21:35:01'),
	(28, 'User jrajca@winsal.com assigned you to Order shipping', 2, 2, '2022-01-26 21:35:01', '2022-01-26 21:35:01'),
	(29, 'User jrajca@winsal.com assigned you to Prepare package', 2, 3, '2022-01-26 21:37:02', '2022-01-26 21:37:02'),
	(30, 'A new order has been created. ExpertNovum due on 2022-01-01', 3, 2, '2022-01-26 21:49:01', '2022-01-26 21:49:01'),
	(31, 'A new order has been created. ExpertNovum due on 2022-01-01', 3, 3, '2022-01-26 21:49:01', '2022-01-26 21:49:01'),
	(32, 'A new order has been created. ExpertNovum due on 2022-01-01', 3, 4, '2022-01-26 21:49:01', '2022-01-26 21:49:01'),
	(33, 'A new order has been created. ExpertNovum due on 2022-01-01', 3, 5, '2022-01-26 21:49:01', '2022-01-26 21:49:01'),
	(34, 'User jrajca@winsal.com assigned you to Measure Items', 3, 3, '2022-01-26 21:49:01', '2022-01-26 21:49:01'),
	(35, 'User jrajca@winsal.com assigned you to Order shipping', 3, 3, '2022-01-26 21:50:01', '2022-01-26 21:50:01'),
	(36, 'User jrajca@winsal.com assigned you to Prepare wares for shipping', 3, 3, '2022-01-26 21:50:01', '2022-01-26 21:50:01'),
	(37, 'User jrajca@winsal.com assigned you to Generate a certifacte of security', 3, 5, '2022-01-26 21:51:02', '2022-01-26 21:51:02'),
	(38, 'User jrajca@winsal.com edited your task - Prepare wares for shipping', 3, 3, '2022-01-26 21:51:02', '2022-01-26 21:51:02'),
	(39, 'User jrajca@winsal.com assigned you to Ship Items (20.12.2021)', 3, 2, '2022-01-26 21:51:02', '2022-01-26 21:51:02'),
	(40, 'An order ExpertNovum 2022-01-01 was archived', 3, 2, '2022-01-26 21:52:01', '2022-01-26 21:52:01'),
	(41, 'An order ExpertNovum 2022-01-01 was archived', 3, 3, '2022-01-26 21:52:01', '2022-01-26 21:52:01'),
	(42, 'An order ExpertNovum 2022-01-01 was archived', 3, 4, '2022-01-26 21:52:01', '2022-01-26 21:52:01'),
	(43, 'An order ExpertNovum 2022-01-01 was archived', 3, 5, '2022-01-26 21:52:01', '2022-01-26 21:52:01'),
	(44, 'Order Walzwerk Winsal 2022-03-15 was updated', 1, 2, '2022-01-26 21:52:01', '2022-01-26 21:52:01'),
	(45, 'Order Walzwerk Winsal 2022-03-15 was updated', 1, 3, '2022-01-26 21:52:01', '2022-01-26 21:52:01'),
	(46, 'Order Walzwerk Winsal 2022-03-15 was updated', 1, 4, '2022-01-26 21:52:01', '2022-01-26 21:52:01'),
	(47, 'Order Walzwerk Winsal 2022-03-15 was updated', 1, 5, '2022-01-26 21:52:01', '2022-01-26 21:52:01'),
	(48, 'Order Politechnika Czestochowska 2022-01-28 was updated', 2, 2, '2022-01-26 21:53:02', '2022-01-26 21:53:02'),
	(49, 'Order Politechnika Czestochowska 2022-01-28 was updated', 2, 3, '2022-01-26 21:53:02', '2022-01-26 21:53:02'),
	(50, 'Order Politechnika Czestochowska 2022-01-28 was updated', 2, 4, '2022-01-26 21:53:02', '2022-01-26 21:53:02'),
	(51, 'Order Politechnika Czestochowska 2022-01-28 was updated', 2, 5, '2022-01-26 21:53:02', '2022-01-26 21:53:02'),
	(52, 'An order ExpertNovum 2022-01-01 was restored from the archive', 3, 2, '2022-01-26 22:01:02', '2022-01-26 22:01:02'),
	(53, 'An order ExpertNovum 2022-01-01 was restored from the archive', 3, 3, '2022-01-26 22:01:02', '2022-01-26 22:01:02'),
	(54, 'An order ExpertNovum 2022-01-01 was restored from the archive', 3, 4, '2022-01-26 22:01:02', '2022-01-26 22:01:02'),
	(55, 'An order ExpertNovum 2022-01-01 was restored from the archive', 3, 5, '2022-01-26 22:01:02', '2022-01-26 22:01:02'),
	(56, 'Order ExpertNovum 2022-01-01 was updated', 3, 2, '2022-01-26 22:02:02', '2022-01-26 22:02:02'),
	(57, 'Order ExpertNovum 2022-01-01 was updated', 3, 3, '2022-01-26 22:02:02', '2022-01-26 22:02:02'),
	(58, 'Order ExpertNovum 2022-01-01 was updated', 3, 4, '2022-01-26 22:02:02', '2022-01-26 22:02:02'),
	(59, 'Order ExpertNovum 2022-01-01 was updated', 3, 5, '2022-01-26 22:02:02', '2022-01-26 22:02:02'),
	(60, 'An order ExpertNovum 2022-01-01 was archived', 3, 2, '2022-01-26 22:02:02', '2022-01-26 22:02:02'),
	(61, 'An order ExpertNovum 2022-01-01 was archived', 3, 3, '2022-01-26 22:02:02', '2022-01-26 22:02:02'),
	(62, 'An order ExpertNovum 2022-01-01 was archived', 3, 4, '2022-01-26 22:02:02', '2022-01-26 22:02:02'),
	(63, 'An order ExpertNovum 2022-01-01 was archived', 3, 5, '2022-01-26 22:02:02', '2022-01-26 22:02:02');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.orders
DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_deadline` date NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.orders: ~3 rows (około)
DELETE FROM `orders`;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`id`, `title`, `client`, `shipping_address`, `shipping_deadline`, `notes`, `archived_at`, `created_at`, `updated_at`) VALUES
	(1, 'Big steel', 'Walzwerk Winsal', 'Altenaer Str. 85, 58769 Nachrodt-Wiblingwerde, Germany', '2022-03-15', 'Internal, present in the warehouse. Cut if needed', NULL, '2022-01-26 21:15:18', '2022-01-26 21:15:18'),
	(2, 'Titanium Sheet', 'Politechnika Czestochowska', 'Generala Jana Henryka Dabrowskiego 69, 42-201 Czestochowa', '2022-01-28', '', NULL, '2022-01-26 21:31:27', '2022-01-26 21:31:27'),
	(3, 'Small Aluminum', 'ExpertNovum', 'Wrobli 38, 40-534 Katowice', '2022-01-01', '', '2022-01-26 22:01:10', '2022-01-26 21:48:07', '2022-01-26 22:01:10');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.password_resets: ~0 rows (około)
DELETE FROM `password_resets`;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.tasks
DROP TABLE IF EXISTS `tasks`;
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `column_number` int(11) NOT NULL DEFAULT 0,
  `order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation_terms` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `validation_comments` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tasks_order_id_foreign` (`order_id`),
  KEY `tasks_user_id_foreign` (`user_id`),
  CONSTRAINT `tasks_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tasks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.tasks: ~18 rows (około)
DELETE FROM `tasks`;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` (`id`, `column_number`, `order_id`, `user_id`, `title`, `description`, `validation_terms`, `validation_comments`, `notes`, `created_at`, `updated_at`) VALUES
	(1, 3, 1, 2, 'Measure Items', 'We do possess all items that are needed. Verify all the measurements', 'Attach documentation ', 'Items need to be cut to fit the order', '', '2022-01-26 21:18:27', '2022-01-26 21:20:46'),
	(2, 3, 1, 4, 'Find a cutter and order a service', 'Items need to fit the requirements', 'Attach mail exchange for requested service', '', '', '2022-01-26 21:23:04', '2022-01-26 21:23:07'),
	(3, 3, 1, 3, 'Prepare shippment for cutting', 'Order transportation, secure items in a package', 'Attach mail exchange / invoice for shipping service. Photos of secured package also required', '', 'I suggest asking our neighbours for help with this', '2022-01-26 21:25:27', '2022-01-26 21:26:19'),
	(4, 1, 1, 2, 'Ship Items For Cutting (28.01.2022)', '', 'Attach signed waybill', '', '', '2022-01-26 21:27:39', '2022-01-26 21:27:43'),
	(5, 0, 1, 2, 'Measure Items Again', 'Make sure that the cutting was successfull', 'Attach measurments and photos', '', '', '2022-01-26 21:28:21', '2022-01-26 21:28:21'),
	(6, 0, 1, 2, 'Receive cutted items (~01.02.2022)', '', 'Attach signed waybill, certificate from cutting company and package photos', '', '', '2022-01-26 21:29:57', '2022-01-26 21:29:57'),
	(7, 3, 2, 5, 'Order items', 'We don\'t have these in our warehouse', 'Attach invoice', '', '', '2022-01-26 21:32:39', '2022-01-26 21:32:43'),
	(8, 3, 2, 3, 'Receive the delivery (15.01.2022)', '', 'Attach photos of package and signed waybill', '', '', '2022-01-26 21:33:27', '2022-01-26 21:33:30'),
	(9, 3, 2, 4, 'Measure Items', '', 'Attach measurments and photos', '', '', '2022-01-26 21:33:54', '2022-01-26 21:34:02'),
	(10, 3, 2, 5, 'Generate a certifacte of security', '', 'Attach said certificate', '', '', '2022-01-26 21:34:22', '2022-01-26 21:34:25'),
	(11, 3, 2, 2, 'Order shipping', '', 'Attach invoice / emails', '', '', '2022-01-26 21:34:54', '2022-01-26 21:34:57'),
	(12, 3, 2, 3, 'Prepare package', '', 'Attach photos and documents generated', '', '', '2022-01-26 21:36:04', '2022-01-26 21:36:06'),
	(13, 3, 2, NULL, 'Send the package', '', 'Attach signed waybill', '', '', '2022-01-26 21:36:28', '2022-01-26 21:36:31'),
	(14, 3, 3, 3, 'Measure Items', '', 'Attach measurments and photos', '', '', '2022-01-26 21:48:31', '2022-01-26 21:48:34'),
	(15, 3, 3, 3, 'Order shipping', '', 'Attach invoice / emails', '', '', '2022-01-26 21:49:31', '2022-01-26 21:49:34'),
	(16, 3, 3, 3, 'Prepare wares for shipping', '', 'Attach photos', '', '', '2022-01-26 21:49:53', '2022-01-26 21:49:55'),
	(17, 3, 3, 5, 'Generate a certifacte of security', '', 'Attach certificate', '', '', '2022-01-26 21:50:13', '2022-01-26 21:50:16'),
	(18, 3, 3, 2, 'Ship Items (20.12.2021)', '', 'Attach signed waybill / photos', '', '', '2022-01-26 21:51:01', '2022-01-26 21:51:15');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.users: ~5 rows (około)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `email`, `password`, `is_admin`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'jrajca@winsal.com', '$2y$10$esseFCJKgG9620nOzqFto.DyOYCzJLC9KpQyfV8fv4s2angyPTqEq', 1, NULL, '2021-12-31 19:04:11', '2021-12-31 19:04:12'),
	(2, 'dwasilewska@winsal.com', '$2y$10$V0fyTX6/wUYCo8/2rW2Np.iNppM2kEUXtCjEALJc5NfSt7K/1zY0q', 0, 'ttoX9QcmwApaypziwbMRA7OSByTWDE0pMTu02JRbVbZaKicwt0HYyC71kJUm', '2021-12-31 18:04:33', '2021-12-31 18:09:20'),
	(3, 'mbrzezinski@winsal.com', '$2y$10$UBmPuLsd3jKFrzXZyS6O/OOtMqgqQrUTJCAKScEqn28PLJJFyEDla', 0, 'GSMEYgSpOzPEOuh5LRrN1BimJwhQyWGtdmAPRHnsCrUoSu1nqXRCyLHEe3HK', '2021-12-31 18:05:54', '2021-12-31 18:12:16'),
	(4, 'gziolkowska@winsal.com', '$2y$10$P7M8t8vnx1z0Rp4neLNTHu/wMlYnCbiXyw4yEfbaRPVH4KwpB2lu6', 0, 'fwMF5BONmcoTBqv8rUXVs2qYqYbIhuCGFn6tMmMfEoQR0MqcTEFD0qxIBXWd', '2021-12-31 18:06:21', '2021-12-31 18:12:36'),
	(5, 'ejankowski@winsal.com', '$2y$10$j/L2UErsRuon8q9Jf9cWT.PJHHaCooiSFIo9/hgzy8xPWC.wQ8HXm', 1, 'YnvxsZlW5CWNrdYgG4jyyOt0wqNT7Fm2tYGJPUs4tSiZRLadfddeVir3Z1Ge', '2021-12-31 18:07:43', '2021-12-31 18:12:53');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
