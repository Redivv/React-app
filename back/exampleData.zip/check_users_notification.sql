-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Wersja serwera:               10.7.1-MariaDB-1:10.7.1+maria~focal - mariadb.org binary distribution
-- Serwer OS:                    debian-linux-gnu
-- HeidiSQL Wersja:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Zrzut struktury bazy danych thesis
DROP DATABASE IF EXISTS `thesis`;
CREATE DATABASE IF NOT EXISTS `thesis` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `thesis`;

-- Zrzut struktury tabela thesis.failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.failed_jobs: ~0 rows (około)
DELETE FROM `failed_jobs`;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.files
DROP TABLE IF EXISTS `files`;
CREATE TABLE IF NOT EXISTS `files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.files: ~0 rows (około)
DELETE FROM `files`;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.file_order
DROP TABLE IF EXISTS `file_order`;
CREATE TABLE IF NOT EXISTS `file_order` (
  `order_id` bigint(20) unsigned NOT NULL,
  `file_id` bigint(20) unsigned NOT NULL,
  KEY `file_order_order_id_foreign` (`order_id`),
  KEY `file_order_file_id_foreign` (`file_id`),
  CONSTRAINT `file_order_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE,
  CONSTRAINT `file_order_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.file_order: ~0 rows (około)
DELETE FROM `file_order`;
/*!40000 ALTER TABLE `file_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_order` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.file_task
DROP TABLE IF EXISTS `file_task`;
CREATE TABLE IF NOT EXISTS `file_task` (
  `task_id` bigint(20) unsigned NOT NULL,
  `file_id` bigint(20) unsigned NOT NULL,
  KEY `file_task_task_id_foreign` (`task_id`),
  KEY `file_task_file_id_foreign` (`file_id`),
  CONSTRAINT `file_task_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE,
  CONSTRAINT `file_task_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.file_task: ~0 rows (około)
DELETE FROM `file_task`;
/*!40000 ALTER TABLE `file_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_task` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.jobs
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.jobs: ~0 rows (około)
DELETE FROM `jobs`;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.migrations: ~10 rows (około)
DELETE FROM `migrations`;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2021_12_03_112744_create_users_table', 1),
	(2, '2021_12_07_151421_create_orders_table', 1),
	(3, '2021_12_09_160135_create_tasks_table', 1),
	(4, '2021_12_11_170808_create_password_resets_table', 1),
	(5, '2021_12_25_113622_create_files_table', 1),
	(6, '2021_12_25_152837_create_file_order_table', 1),
	(7, '2021_12_26_201638_create_file_task_table', 1),
	(8, '2021_12_29_143021_create_notifications_table', 1),
	(9, '2021_12_30_122138_create_jobs_table', 1),
	(10, '2021_12_30_122251_create_failed_jobs_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.notifications
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_order_id_foreign` (`order_id`),
  KEY `notifications_user_id_foreign` (`user_id`),
  CONSTRAINT `notifications_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.notifications: ~0 rows (około)
DELETE FROM `notifications`;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` (`id`, `content`, `order_id`, `user_id`, `created_at`, `updated_at`) VALUES
	(1, 'User mbrzezinski@winsal.com was added', NULL, 2, '2021-12-31 18:06:02', '2021-12-31 18:06:02'),
	(2, 'User gziolkowska@winsal.com was added', NULL, 2, '2021-12-31 18:07:01', '2021-12-31 18:07:01'),
	(3, 'User gziolkowska@winsal.com was added', NULL, 3, '2021-12-31 18:07:01', '2021-12-31 18:07:01'),
	(4, 'User ejankowski@winsal.com was added', NULL, 2, '2021-12-31 18:08:01', '2021-12-31 18:08:01'),
	(5, 'User ejankowski@winsal.com was added', NULL, 3, '2021-12-31 18:08:01', '2021-12-31 18:08:01'),
	(6, 'User ejankowski@winsal.com was added', NULL, 4, '2021-12-31 18:08:01', '2021-12-31 18:08:01');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.orders
DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_deadline` date NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `archived_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.orders: ~0 rows (około)
DELETE FROM `orders`;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.password_resets: ~0 rows (około)
DELETE FROM `password_resets`;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.tasks
DROP TABLE IF EXISTS `tasks`;
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `column_number` int(11) NOT NULL DEFAULT 0,
  `order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation_terms` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `validation_comments` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tasks_order_id_foreign` (`order_id`),
  KEY `tasks_user_id_foreign` (`user_id`),
  CONSTRAINT `tasks_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tasks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.tasks: ~0 rows (około)
DELETE FROM `tasks`;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;

-- Zrzut struktury tabela thesis.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Zrzucanie danych dla tabeli thesis.users: ~0 rows (około)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `email`, `password`, `is_admin`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'jrajca@winsal.com', '$2y$10$esseFCJKgG9620nOzqFto.DyOYCzJLC9KpQyfV8fv4s2angyPTqEq', 1, NULL, '2021-12-31 19:04:11', '2021-12-31 19:04:12'),
	(2, 'dwasilewska@winsal.com', '$2y$10$V0fyTX6/wUYCo8/2rW2Np.iNppM2kEUXtCjEALJc5NfSt7K/1zY0q', 0, 'ttoX9QcmwApaypziwbMRA7OSByTWDE0pMTu02JRbVbZaKicwt0HYyC71kJUm', '2021-12-31 18:04:33', '2021-12-31 18:09:20'),
	(3, 'mbrzezinski@winsal.com', '$2y$10$UBmPuLsd3jKFrzXZyS6O/OOtMqgqQrUTJCAKScEqn28PLJJFyEDla', 0, 'GSMEYgSpOzPEOuh5LRrN1BimJwhQyWGtdmAPRHnsCrUoSu1nqXRCyLHEe3HK', '2021-12-31 18:05:54', '2021-12-31 18:12:16'),
	(4, 'gziolkowska@winsal.com', '$2y$10$P7M8t8vnx1z0Rp4neLNTHu/wMlYnCbiXyw4yEfbaRPVH4KwpB2lu6', 0, 'fwMF5BONmcoTBqv8rUXVs2qYqYbIhuCGFn6tMmMfEoQR0MqcTEFD0qxIBXWd', '2021-12-31 18:06:21', '2021-12-31 18:12:36'),
	(5, 'ejankowski@winsal.com', '$2y$10$j/L2UErsRuon8q9Jf9cWT.PJHHaCooiSFIo9/hgzy8xPWC.wQ8HXm', 1, 'YnvxsZlW5CWNrdYgG4jyyOt0wqNT7Fm2tYGJPUs4tSiZRLadfddeVir3Z1Ge', '2021-12-31 18:07:43', '2021-12-31 18:12:53');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
